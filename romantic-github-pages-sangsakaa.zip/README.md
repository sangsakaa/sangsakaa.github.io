# Romantic Landing Page ❤️

Landing page romantis untuk GitHub Pages.

## Cara pakai

1. Buat repository GitHub bernama `sangsakaa.github.io`.
2. Upload `index.html` ke branch `main`.
3. Buka **Settings → Pages**.
4. Pada **Build and deployment**, pilih source yang sesuai (misalnya GitHub Actions atau branch `main`).
5. Situs akan tersedia di `https://sangsakaa.github.io/`.

Semua tampilan utama ada di satu file `index.html`, jadi mudah diedit.
